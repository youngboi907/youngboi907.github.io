<div style="background: #fff;">
    <div class="ui container center align vertical stripe heading-container">
        <p>•	First of all, install MetaMask <a href="https://metamask.io/">here</a> and put some Ether in it.</p>
        <p>•	To buy ARW, simply click the "Buy Tokens" button and enter the amount of Ether you want to convert to ARW, based on the current Buy Price. When confirming the transaction on MetaMask, be sure to use a high enough gas price so that the price doesn't change drastically while the transaction is in progress. Here you can view recommended gas prices. Buying coins will increase both the Buy Price and Sell Price with 0.00000001 ETH per bought coin once the transaction is complete.</p>
        <p>•	Under "ARW Token Balance" you can see how many ARW you currently own. Note that when cashing out coins, the Buy Price and Sell Price drop afterwards, decreasing the value of your (and everyone else's) coins by 0.00000001 ETH per coin.</p>
        <p>•	Every time ARW are bought or sold, a percentage of the fee from the bought/sold coins will be divided under the current ARW holders (Dividends).</p>
        <p>•	You can move your tokens into Dividends which then is stored as Ether. To do this click on the "Sell Tokens" button - and your tokens will be transferred into Ether based upon the current sell price.</p>
        <p>•	You can also use your dividends to immediately purchase more ARW tokens by selecting "Buy with Dividends".</p>
        <p>•	To cash out your ARW, click the "Withdraw" button and follow the prompts.</p>
    </div>
</div>
